/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattpoeloginandregsysfinal;
// Import statements for required functionality
import java.util.ArrayList; // Allows us to create dynamic lists for storing user accounts
import java.util.Scanner;   // Enables reading user input from the console
import java.util.regex.Pattern; // Provides pattern matching capabilities for validation of text formats

/**
 *
 * @author RC_Student_lab
 */
// Primary class containing all methods and programme logic for user management
public class MattPOELoginandRegSysFinal {
// Input scanner for capturing user keyboard input throughout the application
    static Scanner inputScanner = new Scanner(System.in);
 
    // Dynamic array list that maintains all registered user accounts
    static ArrayList<UserAccount> registeredAccounts = new ArrayList<>();
 
    // Variable that holds the current login result message for display purposes
    static String authMessage = "";
 
    // Main entry point method that executes when the programme launches
    public static void main(String[] args) {
        // Execute the user registration process and capture the result message
        String registrationOutcome = registerUser();
        // Display the registration result to the user
        System.out.println(registrationOutcome);
 
        // Execute the user login process to authenticate the user
        boolean loginResult = loginUser();
        // Display the login outcome using the status message method
        System.out.println(returnLoginStatus(loginResult));
    }
 
    // Internal class definition for storing individual user account data
    static class UserAccount {
        String firstName;        // User's first name
        String lastName;         // User's last name
        String cellNumber;       // User's cell phone number
        String username;         // User's username for login
        String password;         // User's password for authentication
 
        // Constructor method for creating new user account objects
        UserAccount(String firstName, String lastName, String cellNumber, String username, String password) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.cellNumber = cellNumber;
            this.username = username;
            this.password = password;
        }
    }
 
    // Method that validates username format according to specified business rules
    public static boolean checkUserName(String username) {
        if (username.contains("_")) {
            if (username.length() <= 5) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
 
    // Method that evaluates password strength using regular expression patterns
    public static boolean checkPasswordComplexity(String password) {
        // Password validation requires uppercase letter, digit, special character, minimum 8 characters
        String validationPattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/~`|]).{8,}$";
        boolean patternMatch = Pattern.matches(validationPattern, password);
        return patternMatch;
    }
 
    // Method that verifies cell phone number format for South African numbers
    public static boolean checkCellPhoneNumber(String cellNumber) {
        String phonePattern = "^\\+27\\d{9}$";
        return Pattern.matches(phonePattern, cellNumber);
    }
 
    // Method that manages the complete user registration workflow
    public static String registerUser() {
        System.out.println("--- New Account Registration ---");
 
        // Get the user's first name
        System.out.print("Please enter your first name: ");
        String userFirstName = inputScanner.nextLine();
 
        // Get the user's last name
        System.out.print("Please enter your last name: ");
        String userLastName = inputScanner.nextLine();
 
        // Keep asking until the user enters a valid username
        String userUsername = "";
        boolean nameIsValid = false;
        while (nameIsValid == false) {
            System.out.print("Create your username (Must contain underscore _ and be 5 characters maximum): ");
            userUsername = inputScanner.nextLine();
            nameIsValid = checkUserName(userUsername);
 
            if (nameIsValid == false) {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            } else {
                System.out.println("Username successfully captured.");
            }
        }
 
        // Keep asking until the user enters a valid password
        String userPassword = "";
        boolean passwordIsSecure = false;
        while (passwordIsSecure == false) {
            System.out.print("Create your password: ");
            userPassword = inputScanner.nextLine();
            passwordIsSecure = checkPasswordComplexity(userPassword);
 
            if (passwordIsSecure == false) {
                System.out.println("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            } else {
                System.out.println("Password successfully captured.");
            }
        }
 
        // Keep asking until the user enters a valid cell phone number
        String userCellNumber = "";
        boolean cellIsValid = false;
        while (cellIsValid == false) {
            System.out.print("Enter your cell phone number (+27xxxxxxxxx): ");
            userCellNumber = inputScanner.nextLine();
            cellIsValid = checkCellPhoneNumber(userCellNumber);
 
            if (cellIsValid == false) {
                System.out.println("Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again.");
            } else {
                System.out.println("Cell number successfully captured.");
            }
        }
 
        // Create new user account and add it to the registered accounts list
        registeredAccounts.add(new UserAccount(userFirstName, userLastName, userCellNumber, userUsername, userPassword));
 
        // Return confirmation message
        return "Account registration completed successfully!";
    }
 
    // Method that handles the user login process
    public static boolean loginUser() {
        System.out.println("User Login");
 
        // Ask the user for their username
        System.out.print("Please enter your username: ");
        String enteredUsername = inputScanner.nextLine();
 
        // Look through all registered accounts to find matching username
        for (int index = 0; index < registeredAccounts.size(); index++) {
            UserAccount currentAccount = registeredAccounts.get(index);
 
            // Check if the entered username matches any registered account
            if (currentAccount.username.equals(enteredUsername)) {
                boolean passwordMatches = false;
 
                // Keep asking for password until correct one is entered
                while (!passwordMatches) {
                    System.out.print("Please enter your password: ");
                    String enteredPassword = inputScanner.nextLine();
 
                    // Check if the entered password matches the stored password
                    if (currentAccount.password.equals(enteredPassword)) {
                        authMessage = "Welcome " + currentAccount.firstName + ", " + currentAccount.lastName + " it is great to see you again.";
                        return true;
                    } else {
                        // Tell user password is wrong and ask them to try again
                        System.out.println("Incorrect password entered. Please try again.");
                    }
                }
            }
        }
 
        // Set message when username is not found
        authMessage = "Username not found in system. Please register first.";
        return false;
    }
 
    // Method that returns the current authentication status message
    public static String returnLoginStatus(boolean authenticationStatus) {
        return authMessage;
    }
}